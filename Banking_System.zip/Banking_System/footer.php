<link rel="stylesheet" type="text/css" href="footer.css">
<footer>
<div class="container">
<div class="follow_us">
    <label>Follow Us</label>
    <ul>
        <li><a href="https://www.facebook.com/">Facebook</a></li>
        <li><a href="https://twitter.com/">Twitter</a></li>
        <li><a href="https://www.instagram.com/">Instagram</a></li>
    
    </ul>
    </div>
    <div class="contact" id="contactus">
        <label>Contact Us</label>
        <ul>
            <p>1149 Bolman Court,</p><p>Baylis, Illinois 69690</p>
            <p>Tel : 217-336-0173</p>
            <p> Email: contact@obsphp</p>
            
        </ul>
    </div>
        <div class="links">
        <label>Important Links</label>
            <ul>    
            <li><a href="index.php#aboutus" target="_blank">Index</a></li>
            <li><a href="view_active_cust.php">View all Customers</a></li>
            <li><a href="view_cust_ac_no.php">Customer Details</a></li>
            <li><a href="credit_cust.php">Credit Customer </a></li>
            <li><a href="view_transaction.php">View all Transaction</a></li>
        </ul><br>
    </div>
    <div class="links">

            <label>Important Links</label>
            <ul> 
            <li><a href="debit_card_form.php">Debit card</a></li> 
            <li><a href="view_debit_card.php">View all Debit Card</a></li>    
            <li><a href="Approve_Panding_Account.php">Pendding Account</a></li>
            <li><a href="delete_cust_acc.php">Delete Cust</a></li>
            <li><a href="check_book.php">Check book</a></li> 
        </ul><br>
    </div>
    </div>
    <div class="copyright">
        <span>Copyright &copy; 2023 Online Banking System. All rights reserved.</span>
    </div>
    
    <div class="bestview">
    <span>Site best viewed at 1024 x 768 resolution in Internet Explorer , Google Chrome , Firefox  and Safari </span>
    
    </div>

</footer>
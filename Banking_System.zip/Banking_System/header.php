<link rel="stylesheet" type="text/css" href="header.css">
       <div class="header_main">
        	<div class="navBar">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="index.php#aboutus">About Us</a></li>
                		<li><a href="index.php#contactus">Contact Us</a></li>
                		<!-- <li><a href="help.php">Need Help??</a></li> -->
				<li><a href="staff_login.php">Staff Login</a></li>
			
			</ul>
		</div>
	 	
	 		<a href="index.php">
	 			<div class="logo-name">
					<div class="logo">
             			<img class="logo_img" src="img/chase.jpg">
					</div>
				
		
					<div class="name">
						<h5>Sky Bank Of India</h5></a><br>
						<h6>Banking System</h6></a><br>

					</div>
        		</div>
            
            
            <div class="dif_banking">

				<div class="retail_banking">
					<a href="#"> </a>
				</div>
			
				<div class="corporate_banking">
					<a href="#"> </a>
				</div>

				<div class="international_banking">
					<a href="#"> </a>
				</div>

				<div class="international_banking">
					<a href="#"> </a>
				</div>
                
            	<div class="bank_servic">
					<a href="#"> </a>
				</div>
		</div>
            
           
			
	</div>


	<!-- Retail Banking
Corporate Banking
International Banking
Apply Mobile Banking
Services -->
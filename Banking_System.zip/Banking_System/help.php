<html>
<head>
<link rel="stylesheet" type="text/css" href="gst.css">
<title>Help - Sky Bank of India</title>
</head>
<body>
<?php 
    include "header.php";
include 'customer_profile_header.php';
    //include "Navibar.php";
    ?>
    <br><br>
    <h1><center>Sky Bank of India</center></h1>
<article>
    <!-- <h1>Taxes</h1> -->
<h2>Need help?</h2><br>
<a href = "#">  1)How to activate mobile banking using activation key?</a><br>
Activate your sky bank of india activation key already generated via ATM(Debit Card).You should be have Debit card number and Debit card pin.you get Debit card after you eligable to active mobile banking.<br>
<a href = "#"> 2)How to register using debit card and bank account number?</a><br>
Go to bank and fill up the Debit card form provide your nearest barnch.Reqired for Username,PAN Number,DOB,Register mobile number to bank.After complete this process Generate Debit Card Number and Debit Card Pin.if you are change your Debit Card Pin so go your nearest ATM Machine and change it soon as possible.<br>
<a href = "#"> 3)How to register your bank account online?</a><br>
clicking to New Customer Registration.Open Form,Fill this Form valid information After your conformation.process has been complete to your bank and provide customer id , application no,Account number.<br>
<a href = "#"> 4)How to Login using password?</a><br>
After Registration Form of Account opening and ebanking Form , Customer create password for your security purpose and login to bank.After Login check your Profile,update your profile pic. ,Check your Bank Statment,Change Password.<br>
<a href = "#"> 5)How to update your information if customer information is change/update/worng?</a><br>
check your profile if customer change your profile so visit nearest branch and change your profile.<br>
<a href = "#"> 6)How to Fund Transfer?</a><br>
Fund Transfer means Instant Payment. Payer A/C No. required amounr[required Balance],Remark[purpose]and details submit. after process Gerate otp your Register mobile no to bank. OTP is required.Complete process after OTP.Fund will be Sucess full Transfer.and Gerate Recipe to fund Transfer.<br>


</article>

<?php include 'footer.php';?>
 </body>
 </html>

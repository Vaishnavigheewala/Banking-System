<link rel="stylesheet" type="text/css" href="header.css">
       <div class="header_main">
        		<a href="index.php">
	 			<div class="logo-name">
					<div class="logo">
             			<img class="logo_img" src="img/chase.jpg">
					</div>
				
		
					<div class="name">
						<h5>Sky Bank Of India</h5></a><br>
						<h6>Banking System</h6></a><br>

					</div>
        		</div>
            
            
            				
            			<div class="dif_banking">
            				<a href="#"> </a>
            			</div>;
            			

				<div class="retail_banking">
					<a href="#"> </a>
				</div>
			
				<div class="corporate_banking">
					<a href="#"> </a>
				</div>

				<div class="international_banking">
					<a href="#"> </a>
				</div>

				<div class="international_banking">
					<a href="#"> </a>
				</div>
                
            			<div class="bank_servic">
					<a href="#"> </a>
				</div>


            
           
			
	</div>

